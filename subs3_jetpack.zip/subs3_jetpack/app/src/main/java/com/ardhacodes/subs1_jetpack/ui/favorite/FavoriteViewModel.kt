package com.ardhacodes.subs1_jetpack.ui.favorite

class FavoriteViewModel {
}