package com.ardhacodes.subs1_jetpack.data.source.remote.vo

enum class StatusResponse {
    SUCCESS,
    ERROR
}